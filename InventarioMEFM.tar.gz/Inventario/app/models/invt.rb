class Invt < ApplicationRecord
end
