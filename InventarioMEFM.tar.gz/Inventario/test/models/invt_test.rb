require 'test_helper'

class InvtTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
